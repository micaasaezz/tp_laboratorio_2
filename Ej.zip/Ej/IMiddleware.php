<?php
interface IMiddleware 
{
    static function VerificarUsuario($request, $response, $next);
}
?>