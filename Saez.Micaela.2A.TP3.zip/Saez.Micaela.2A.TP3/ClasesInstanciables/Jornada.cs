﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> _alumnos;
        private Universidad.EClases _clase;
        private Profesor _instructor;

        public List<Alumno> Alumnos
        {
            get { return this._alumnos; }
            set { this._alumnos = value; }
        }
        public Universidad.EClases Clase
        {
            get { return this._clase; }
            set { this._clase = value; }
        }
        public Profesor Instructor
        {
            get { return this._instructor; }
            set { this._instructor = value; }
        }

        public static bool Guardar(Jornada jornada)
        {
            Texto archivoTexto = new Texto();

            return archivoTexto.Guardar("Jornada.txt", jornada.ToString());
        }
        private Jornada()
        {
            this._alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clase, Profesor instructor)
            :this()
        {
            this._clase = clase;
            this._instructor = instructor;
        }
        public static string Leer()
        {
            string ret = "";
            Texto archivoTexto = new Texto();
            archivoTexto.Leer("Jornada.txt", out ret);

            return ret;
        }
        public static bool operator ==(Jornada j, Alumno a)
        {
            bool ret = false;
            foreach(Alumno i in j._alumnos)
            {
                if( i == a)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
            try
            {
                if (j != a)
                {
                    Jornada jornada = new Jornada();
                    jornada._alumnos = j._alumnos;
                    jornada._clase = j._clase;
                    jornada._instructor = j._instructor;

                    jornada._alumnos.Add(a);
                    return jornada;
                }
                else
                {
                    throw new AlumnoRepetidoException();
                }
            }
            catch(AlumnoRepetidoException e)
            {
                Console.WriteLine(e.Message);
            }
            
            return j;
        }
        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("CLASE DE ");
            ret.AppendLine(this.Clase.ToString());
            ret.Append(this.Instructor.ToString());
            foreach (Alumno a in this.Alumnos)
            {
                ret.AppendLine(a.ToString());
            }
            return ret.ToString();
        }



    }
}
