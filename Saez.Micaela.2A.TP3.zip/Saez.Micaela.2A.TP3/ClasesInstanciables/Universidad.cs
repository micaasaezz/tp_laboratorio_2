﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
    public class Universidad
    {
        private List<Alumno> _alumnos;
        private List<Jornada> _jornadas;
        private List<Profesor> _profesores;

        public List<Alumno> Alumnos
        {
            get { return this._alumnos; }
            set { this._alumnos = value; }
        }
        public List<Profesor> Profesores
        {
            get { return this._profesores; }
            set { this._profesores = value; }
        }
        public List<Jornada> Jornadas
        {
            get { return this._jornadas; }
            set { this._jornadas = value; }
        }
        public Jornada this[int i]
        {
            get { return this._jornadas[i]; }
            set { this._jornadas[i] = value; }
        }


        public Universidad()
        {
            this._alumnos = new List<Alumno>();
            this._jornadas = new List<Jornada>();
            this._profesores = new List<Profesor>();
        }


        public static bool Guardar(Universidad gim)
        {
            Xml<Universidad> archivoXML = new Xml<Universidad>();

            return archivoXML.Guardar("Universidad.xml", gim);
        }
        public static Universidad Leer()
        {
            Universidad univ = new Universidad();
            Xml<Universidad> archivoXML = new Xml<Universidad>();
            archivoXML.Leer("Universidad.xml", out univ);
            return univ;
        }
        private static string MostrarDatos(Universidad gim)
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine("JORNADA:");
            foreach (Jornada item in gim.Jornadas)
            {
                ret.AppendLine(item.ToString());
                ret.AppendLine("<-------------------------------->");
            }
            return ret.ToString();
        }

        public static bool operator ==(Universidad g, Alumno a)
        {
            bool ret = false;
            foreach (Alumno item in g.Alumnos)
            {
                if(item == a)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }
        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }
        public static Profesor operator ==(Universidad g, EClases clase)
        {
            foreach (Profesor item in g.Profesores)
            {
                if (item == clase)
                {
                    return item;
                }
            }

            throw new SinProfesorException();
        }
        public static Profesor operator !=(Universidad g, EClases clase)
        {
            Profesor ret = new Profesor();
            foreach (Profesor item in g.Profesores)
            {
                if (item != clase)
                {
                     ret = item;
                }
            }
            return ret;
        }
        public static bool operator ==(Universidad g, Profesor i)
        {
            bool ret = false;
            foreach (Profesor item in g.Profesores)
            {
                if (item == i)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }
        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }
        public static Universidad operator +(Universidad g, Alumno a)
        {
            Universidad univ = new Universidad();
            univ = g;
            if (g != a) 
            {
                g.Alumnos.Add(a);
            }
            return univ;
        }
        public static Universidad operator +(Universidad g, EClases clase)
        {
            Universidad univ = new Universidad();
            Jornada j = new Jornada(clase, g == clase);
            univ = g;
            foreach (Alumno item in univ.Alumnos)
            {
                if (item == clase)
                {
                    j += item;
                }
            }
            univ.Jornadas.Add(j);
            return univ;
        }
        public static Universidad operator +(Universidad g, Profesor i)
        {
            Universidad univ = new Universidad();
            univ = g;
            if (g != i)
            {
                g.Profesores.Add(i);
            }
            return univ;
        }

        public override string ToString()
        {
            return Universidad.MostrarDatos(this);
        }


        public enum EClases
        {
            Programacion, Laboratorio, Legislacion, SPD
        }

    }
}



