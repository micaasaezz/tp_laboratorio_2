﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria
{
    public class Numero
    {
        private double _numero;


        private static double ValidarNumero(string numero)
        {
            double retorno;
            if(! double.TryParse(numero, out retorno))
            {
                retorno = 0;
            }
            return retorno;
        }

        private void SetNumero(string numero)
        {
            this._numero = Numero.ValidarNumero(numero);
        }


        public Numero() :this(0)
        {

        }
        public Numero(double numero):this(numero.ToString())
        {

        }
        public Numero(string numero)
        {
            this.SetNumero(numero);
        }

        public double GetNumero()
        {
            return this._numero;
        }

    }
}
