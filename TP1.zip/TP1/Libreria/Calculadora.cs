﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria
{
    public class Calculadora
    {
        public static double Operar(Numero numero1, Numero numero2, String operador)
        {
            double resultado = 0;
            operador = Calculadora.ValidarOperador(operador);

            switch (operador)
            {
                case "+":
                    resultado = numero1.GetNumero() + numero2.GetNumero();
                    break;
                case "-":
                    resultado = numero1.GetNumero() - numero2.GetNumero();
                    break;
                case "*":
                    resultado = numero1.GetNumero() * numero2.GetNumero();
                    break;
                case "/":
                    if(numero2.GetNumero() == 0)
                    {
                        resultado = 0;
                    }
                    else
                    {
                        resultado = numero1.GetNumero() / numero2.GetNumero();
                    }
                    break;
            }

            return resultado;

        }

        public static string ValidarOperador(string operador)
        {
            if(operador != "*" && operador != "-" && operador != "/")
            {
                operador = "+";
            }

            return operador;
        }

        
    }
}
