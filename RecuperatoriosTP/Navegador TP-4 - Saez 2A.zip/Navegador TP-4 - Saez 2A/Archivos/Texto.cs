﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        string _archivo;
        public Texto(string archivo)
        {
            this._archivo = archivo;
        }

        

        public bool leer(out List<string> datos)
        {
            StreamReader lector = new StreamReader(this._archivo);
            datos = new List<string>();
            try
            {
                while (!lector.EndOfStream)
                {
                    datos.Add(lector.ReadLine());
                }
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                lector.Close();
            }
            return true;
        }
        public bool guardar(string datos)
        {
            StreamWriter escritor = new StreamWriter(this._archivo, true);
            try
            {
                escritor.WriteLine(datos);
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                escritor.Close();
            }
            return true;
        }

        

    }
}
