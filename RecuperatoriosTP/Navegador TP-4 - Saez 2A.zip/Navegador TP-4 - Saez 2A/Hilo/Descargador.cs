﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net; // Avisar del espacio de nombre
using System.ComponentModel;

namespace Hilo
{

    public delegate void DelProgreso(int progress);
    public delegate void DelDescargaCompleta(string html);

    public class Descargador
    {
        private string _html;
        private Uri _direccion;
        private int _progress;

        public Descargador(Uri direccion)
        {
            this._html = direccion.ToString();
            this._direccion = direccion;
            this._progress = 0;
        }

        public int Progreso { get { return this._progress; } }
        public string Html { get { return this._html; } }

        public void IniciarDescarga()
        {
            try
            {
                WebClient cliente = new WebClient();
                cliente.DownloadProgressChanged += new DownloadProgressChangedEventHandler(WebClientDownloadProgressChanged);
                cliente.DownloadStringCompleted += new DownloadStringCompletedEventHandler(WebClientDownloadCompleted);

                cliente.DownloadStringAsync(this._direccion);
            }
            catch (Exception)
            {
            }
        }

        public event DelProgreso Progress;
        private void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            this.Progress(e.ProgressPercentage);
        }


        public event DelDescargaCompleta Download;
        private void WebClientDownloadCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            this.Download(e.Result);
        }
    }


}
