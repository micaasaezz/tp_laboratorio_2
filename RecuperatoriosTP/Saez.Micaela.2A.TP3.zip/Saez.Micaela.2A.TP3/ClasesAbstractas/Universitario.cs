﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int _legajo;

        public Universitario()
        {

        }
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :base(nombre, apellido, dni, nacionalidad)
        {
            this._legajo = legajo;
        }

        public override bool Equals(object obj)
        {
            return obj is Universitario && this == (Universitario)obj;
        }

        protected virtual string MostrarDatos()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.ToString());
            ret.AppendLine("LEGAJO NUMERO: " + this._legajo);
            return ret.ToString();
        }

        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            return pg1.DNI == pg2.DNI || pg1._legajo == pg2._legajo;
        }
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }

        protected abstract string ParticiparEnClase();
        

    }
}
